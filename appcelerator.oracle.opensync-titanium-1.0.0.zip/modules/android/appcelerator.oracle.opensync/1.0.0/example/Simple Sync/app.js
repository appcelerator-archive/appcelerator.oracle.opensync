// Sample application to demonstrate the capabilities of the Oracle Opensync module

var navigator = require('utility/navigator').openAppWindow({
	viewName: 'sync'
});



